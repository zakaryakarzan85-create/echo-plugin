@echo off
REM Requires JDK 21 and Maven on PATH
mvn clean package
echo.
echo Your jar is in the target folder: ShardCore-1.0.0.jar
pause
