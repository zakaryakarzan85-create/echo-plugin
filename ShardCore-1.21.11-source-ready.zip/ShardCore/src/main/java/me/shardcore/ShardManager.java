package me.shardcore;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Stores every player's shard and lives in plugins/ShardCore/players.yml.
 * Data is keyed by UUID and kept in memory, so it is never affected by death or respawn.
 */
public final class ShardManager {

    public static final int MIN_LIVES = 1;
    public static final int DEFAULT_LIVES = 3;
    public static final int MAX_LIVES = 6;

    private static final class Data {
        ShardType shard;
        int lives = DEFAULT_LIVES;
    }

    private final ShardCore plugin;
    private final File file;
    private final Map<UUID, Data> data = new HashMap<>();
    private final Map<UUID, long[]> cooldowns = new HashMap<>();
    private boolean dirty;

    public ShardManager(ShardCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
    }

    // ------------------------------------------------------------ persistence

    public void load() {
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        for (String key : yml.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                ShardType type = ShardType.fromId(yml.getString(key + ".shard", ""));
                if (type == null) {
                    continue;
                }
                Data d = new Data();
                d.shard = type;
                d.lives = clamp(yml.getInt(key + ".lives", DEFAULT_LIVES));
                data.put(id, d);
            } catch (IllegalArgumentException ignored) {
                // bad UUID key, skip
            }
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Data> e : data.entrySet()) {
            String key = e.getKey().toString();
            yml.set(key + ".shard", e.getValue().shard.id());
            yml.set(key + ".lives", e.getValue().lives);
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().severe("Could not save players.yml: " + ex.getMessage());
        }
    }

    public void saveIfDirty() {
        if (dirty) {
            save();
        }
    }

    // ------------------------------------------------------------ shard + lives

    public boolean has(UUID id) {
        return data.containsKey(id);
    }

    /** Makes sure the player has a shard (random on first join, 3 lives). */
    public void ensure(Player p) {
        entry(p);
    }

    private Data entry(Player p) {
        return data.computeIfAbsent(p.getUniqueId(), id -> {
            Data d = new Data();
            d.shard = ShardType.random(null);
            d.lives = DEFAULT_LIVES;
            dirty = true;
            return d;
        });
    }

    public ShardType getShard(Player p) {
        return entry(p).shard;
    }

    public int getLives(Player p) {
        return entry(p).lives;
    }

    public void setShard(Player p, ShardType type) {
        entry(p).shard = type;
        dirty = true;
    }

    /** Picks a different random shard. Lives are kept. */
    public ShardType reroll(Player p) {
        Data d = entry(p);
        d.shard = ShardType.random(d.shard);
        dirty = true;
        return d.shard;
    }

    public int setLives(Player p, int lives) {
        Data d = entry(p);
        d.lives = clamp(lives);
        dirty = true;
        return d.lives;
    }

    public int addLives(Player p, int delta) {
        return setLives(p, entry(p).lives + delta);
    }

    private static int clamp(int lives) {
        return Math.max(MIN_LIVES, Math.min(MAX_LIVES, lives));
    }

    /** Ability power multiplier: 0.80 at 1 life, 1.00 at 3 lives, 1.30 at 6 lives (default config). */
    public double scale(Player p) {
        double perLife = plugin.getConfig().getDouble("scaling-per-life", 0.10);
        return Math.max(0.1, 1.0 + (getLives(p) - DEFAULT_LIVES) * perLife);
    }

    // ------------------------------------------------------------ cooldowns

    public int cooldownSeconds(int slot) {
        return plugin.getConfig().getInt("cooldowns.ability-" + slot, slot == 1 ? 20 : 45);
    }

    public long remainingMs(Player p, int slot) {
        long[] ready = cooldowns.get(p.getUniqueId());
        if (ready == null) {
            return 0;
        }
        return Math.max(0, ready[slot] - System.currentTimeMillis());
    }

    public void startCooldown(Player p, int slot) {
        long[] ready = cooldowns.computeIfAbsent(p.getUniqueId(), k -> new long[3]);
        ready[slot] = System.currentTimeMillis() + cooldownSeconds(slot) * 1000L;
    }

    // ------------------------------------------------------------ HUD

    /** MiniMessage string for the action bar. */
    public String hud(Player p) {
        Data d = entry(p);
        return d.shard.colored()
                + " <dark_gray>|</dark_gray> <red>\u2665 " + d.lives + "/" + MAX_LIVES + "</red>"
                + " <dark_gray>|</dark_gray> <gray>/attack</gray> " + cd(p, 1)
                + " <dark_gray>|</dark_gray> <gray>/attack 2</gray> " + cd(p, 2);
    }

    private String cd(Player p, int slot) {
        long ms = remainingMs(p, slot);
        return ms <= 0 ? "<green>Ready</green>" : "<red>" + ((ms + 999) / 1000) + "s</red>";
    }
}
