package me.shardcore;

import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Every ability. Each method receives the caster and a power multiplier
 * (0.80 at 1 life ... 1.30 at 6 lives) and returns true when the ability was used.
 * Abilities never break or place blocks.
 */
public final class Abilities {

    private Abilities() {
    }

    /** True while an ability is applying damage, so passives (Thorn Aura) ignore it. */
    static boolean dealingAbilityDamage = false;

    /** Active Thorn Auras. */
    static final Map<UUID, Aura> THORNS = new HashMap<>();

    record Aura(long expiresAt, double power) {
    }

    // =====================================================================
    // EMBER
    // =====================================================================

    static boolean fireLance(Player p, double s) {
        LivingEntity t = rayTarget(p, 20);
        if (t == null) {
            return noTarget(p);
        }
        line(muzzle(p), center(t).toLocation(t.getWorld()), Particle.FLAME, null, 3);
        hit(p, t, 4 * s);
        t.setFireTicks(Math.max(t.getFireTicks(), ticks(3, s)));
        sound(p.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 1f);
        return true;
    }

    static boolean infernoRing(Player p, double s) {
        Location c = chest(p);
        for (LivingEntity t : nearby(p, c, 5)) {
            hit(p, t, 6 * s);
            t.setFireTicks(Math.max(t.getFireTicks(), ticks(4, s)));
            knock(c, t, 0.5, 0.25);
        }
        ring(c.clone().add(0, -0.7, 0), 5, 48, Particle.FLAME, null);
        ring(c.clone().add(0, -0.7, 0), 2.5, 24, Particle.FLAME, null);
        fx(c, Particle.SMOKE, 20, 1.5, 0.05);
        sound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 1.4f);
        return true;
    }

    // =====================================================================
    // GALE
    // =====================================================================

    static boolean gustDash(Player p, double s) {
        double yaw = Math.toRadians(p.getLocation().getYaw());
        Vector dir = new Vector(-Math.sin(yaw), 0, Math.cos(yaw));
        p.setVelocity(dir.multiply(1.4 * s).setY(0.25));
        sound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 0.8f, 1.5f);

        final Set<UUID> alreadyHit = new HashSet<>();
        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (!p.isOnline() || p.isDead() || ++tick > 8) {
                    p.setFallDistance(0);
                    cancel();
                    return;
                }
                Location l = chest(p);
                fx(l, Particle.CLOUD, 5, 0.25, 0.02);
                for (LivingEntity e : nearby(p, l, 1.8)) {
                    if (!alreadyHit.add(e.getUniqueId())) {
                        continue;
                    }
                    hit(p, e, 3 * s);
                    knock(l, e, 0.7, 0.25);
                }
            }
        }.runTaskTimer(ShardCore.instance(), 1L, 1L);
        return true;
    }

    static boolean cyclone(Player p, double s) {
        Location c = chest(p);
        for (LivingEntity t : nearby(p, c, 5)) {
            hit(p, t, 4 * s);
            t.setVelocity(new Vector(0, 0.9 * s, 0));
            give(t, PotionEffectType.SLOWNESS, ticks(3, s), 0);
        }
        for (int h = 0; h < 4; h++) {
            ring(c.clone().add(0, -0.8 + h * 0.8, 0), 1.2 + h * 1.1, 20 + h * 6, Particle.CLOUD, null);
        }
        sound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1f, 0.7f);
        return true;
    }

    // =====================================================================
    // TERRA
    // =====================================================================

    static boolean stoneSkin(Player p, double s) {
        give(p, PotionEffectType.RESISTANCE, ticks(5, s), 1);
        give(p, PotionEffectType.SLOWNESS, ticks(5, s), 0);
        fx(chest(p), Particle.BLOCK, 40, 0.5, 0.05, Material.STONE.createBlockData());
        sound(p.getLocation(), Sound.ENTITY_IRON_GOLEM_DAMAGE, 1f, 0.8f);
        return true;
    }

    static boolean rockSpike(Player p, double s) {
        double range = freeRange(p, 10);
        Vector dir = p.getEyeLocation().getDirection();
        Location from = muzzle(p);
        for (double d = 1; d <= range; d += 1) {
            Location l = p.getEyeLocation().add(dir.clone().multiply(d)).add(0, -0.8, 0);
            fx(l, Particle.BLOCK, 12, 0.3, 0.05, Material.STONE.createBlockData());
        }
        for (LivingEntity t : lineTargets(p, range, 1.5)) {
            hit(p, t, 6 * s);
            t.setVelocity(new Vector(0, 0.7, 0));
            give(t, PotionEffectType.SLOWNESS, ticks(2, s), 1);
        }
        sound(from, Sound.BLOCK_STONE_BREAK, 1.2f, 0.6f);
        return true;
    }

    // =====================================================================
    // VOLT
    // =====================================================================

    static boolean chainLightning(Player p, double s) {
        LivingEntity first = rayTarget(p, 18);
        if (first == null) {
            return noTarget(p);
        }
        Set<UUID> chained = new HashSet<>();
        Location from = muzzle(p);
        LivingEntity cur = first;
        for (int i = 0; i < 3 && cur != null; i++) {
            chained.add(cur.getUniqueId());
            Location to = center(cur).toLocation(cur.getWorld());
            line(from, to, Particle.ELECTRIC_SPARK, null, 4);
            sound(to, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.4f, 1.8f);
            hit(p, cur, (i == 0 ? 5 : 3) * s);
            from = to;
            cur = nearest(p, to, 5, chained);
        }
        return true;
    }

    static boolean thunderCall(Player p, double s) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTrace(eye, eye.getDirection(), 25,
                FluidCollisionMode.NEVER, true, 0.5, e -> valid(p, e));
        if (r == null) {
            return noTarget(p);
        }
        final Location spot = r.getHitPosition().toLocation(p.getWorld());
        sound(spot, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.3f, 2f);

        new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                if (!p.isOnline()) {
                    cancel();
                    return;
                }
                if (elapsed >= 24) {
                    spot.getWorld().strikeLightningEffect(spot);
                    for (LivingEntity t : nearby(p, spot, 3)) {
                        hit(p, t, 7 * s);
                    }
                    fx(spot, Particle.ELECTRIC_SPARK, 40, 1.5, 0.3);
                    cancel();
                    return;
                }
                ring(spot.clone().add(0, 0.15, 0), 3, 24, Particle.ELECTRIC_SPARK, null);
                elapsed += 4;
            }
        }.runTaskTimer(ShardCore.instance(), 0L, 4L);
        return true;
    }

    // =====================================================================
    // FROST
    // =====================================================================

    static boolean frostBolt(Player p, double s) {
        LivingEntity t = rayTarget(p, 20);
        if (t == null) {
            return noTarget(p);
        }
        line(muzzle(p), center(t).toLocation(t.getWorld()), Particle.SNOWFLAKE, null, 4);
        hit(p, t, 3 * s);
        give(t, PotionEffectType.SLOWNESS, ticks(4, s), 1);
        chill(t);
        sound(p.getLocation(), Sound.ENTITY_SNOW_GOLEM_SHOOT, 1f, 0.8f);
        return true;
    }

    static boolean absoluteZero(Player p, double s) {
        Location c = chest(p);
        for (LivingEntity t : nearby(p, c, 5)) {
            hit(p, t, 3 * s);
            give(t, PotionEffectType.SLOWNESS, ticks(3, s), 2);
            chill(t);
        }
        for (int i = 1; i <= 3; i++) {
            ring(c.clone().add(0, -0.7, 0), i * 1.6, 16 + i * 10, Particle.SNOWFLAKE, null);
        }
        sound(p.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 0.7f);
        return true;
    }

    // =====================================================================
    // VENOM
    // =====================================================================

    private static final Particle.DustOptions GREEN_DUST = new Particle.DustOptions(Color.fromRGB(70, 190, 60), 1.4f);

    static boolean toxicDart(Player p, double s) {
        LivingEntity t = rayTarget(p, 20);
        if (t == null) {
            return noTarget(p);
        }
        line(muzzle(p), center(t).toLocation(t.getWorld()), Particle.DUST, GREEN_DUST, 3);
        hit(p, t, 2 * s);
        give(t, PotionEffectType.POISON, ticks(3, s), 1);
        sound(p.getLocation(), Sound.ENTITY_WITCH_THROW, 1f, 1.2f);
        return true;
    }

    static boolean plagueCloud(Player p, double s) {
        final Location c = p.getLocation().clone();
        final int duration = ticks(5, s);
        sound(c, Sound.ENTITY_SPLASH_POTION_BREAK, 1f, 0.8f);

        new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                if (elapsed >= duration) {
                    cancel();
                    return;
                }
                ring(c.clone().add(0, 0.2, 0), 4, 28, Particle.DUST, GREEN_DUST);
                fx(c.clone().add(0, 0.8, 0), Particle.WITCH, 10, 1.6, 0.02);
                if (elapsed % 10 == 0) {
                    for (LivingEntity t : nearby(p, c.clone().add(0, 1, 0), 4)) {
                        maintain(t, PotionEffectType.POISON, 50, 0);
                        maintain(t, PotionEffectType.SLOWNESS, 40, 0);
                    }
                }
                elapsed += 5;
            }
        }.runTaskTimer(ShardCore.instance(), 0L, 5L);
        return true;
    }

    // =====================================================================
    // SHADE
    // =====================================================================

    static boolean shadowStep(Player p, double s) {
        Location start = p.getLocation();
        Vector dir = start.getDirection();
        dir.setY(Math.max(-0.3, dir.getY())); // looking steeply down should not block the blink
        dir.normalize();

        double max = 7 * s;
        Location last = null;
        for (double d = 0.5; d <= max; d += 0.5) {
            Location probe = start.clone().add(dir.clone().multiply(d));
            if (!hasRoom(probe)) {
                break;
            }
            last = probe;
        }
        if (last == null) {
            ShardCore.msg(p, "<gray>No room to blink there.</gray>");
            return false;
        }

        Location dest = new Location(last.getWorld(), Math.floor(last.getX()) + 0.5, last.getY(),
                Math.floor(last.getZ()) + 0.5, start.getYaw(), start.getPitch());

        fx(chest(p), Particle.SMOKE, 25, 0.4, 0.03);
        p.teleport(dest);
        fx(chest(p), Particle.SMOKE, 25, 0.4, 0.03);
        fx(chest(p), Particle.PORTAL, 30, 0.5, 0.2);
        sound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 0.8f, 1.3f);
        return true;
    }

    static boolean veilOfNight(Player p, double s) {
        give(p, PotionEffectType.INVISIBILITY, ticks(4, s), 0);
        give(p, PotionEffectType.SPEED, ticks(4, s), 0);
        Location c = chest(p);
        for (LivingEntity t : nearby(p, c, 6)) {
            give(t, PotionEffectType.BLINDNESS, ticks(2, s), 0);
        }
        fx(c, Particle.SQUID_INK, 40, 0.8, 0.05);
        ring(c.clone().add(0, -0.7, 0), 6, 40, Particle.SMOKE, null);
        sound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.6f, 0.6f);
        return true;
    }

    // =====================================================================
    // VERDANT
    // =====================================================================

    static boolean regrowth(Player p, double s) {
        give(p, PotionEffectType.REGENERATION, ticks(4, s), 2);
        fx(chest(p), Particle.HAPPY_VILLAGER, 25, 0.6, 0);
        sound(p.getLocation(), Sound.BLOCK_GRASS_BREAK, 1f, 0.8f);
        return true;
    }

    static boolean thornAura(Player p, double s) {
        final int duration = ticks(6, s);
        give(p, PotionEffectType.RESISTANCE, duration, 0);
        THORNS.put(p.getUniqueId(), new Aura(System.currentTimeMillis() + duration * 50L, s));
        sound(p.getLocation(), Sound.BLOCK_GRASS_BREAK, 1f, 0.5f);

        new BukkitRunnable() {
            @Override
            public void run() {
                Aura a = THORNS.get(p.getUniqueId());
                if (!p.isOnline() || p.isDead() || a == null || System.currentTimeMillis() > a.expiresAt()) {
                    if (a != null && System.currentTimeMillis() > a.expiresAt()) {
                        THORNS.remove(p.getUniqueId());
                    }
                    cancel();
                    return;
                }
                ring(chest(p), 0.9, 8, Particle.HAPPY_VILLAGER, null);
            }
        }.runTaskTimer(ShardCore.instance(), 0L, 8L);
        return true;
    }

    // =====================================================================
    // VOID
    // =====================================================================

    static boolean singularityPull(Player p, double s) {
        LivingEntity t = rayTarget(p, 18);
        if (t == null) {
            return noTarget(p);
        }
        Vector toward = p.getLocation().toVector().subtract(t.getLocation().toVector());
        double dist = toward.length();
        toward.setY(0);

        line(muzzle(p), center(t).toLocation(t.getWorld()), Particle.PORTAL, null, 3);
        hit(p, t, 2 * s);

        Vector push = new Vector(0, 0.4, 0);
        if (toward.lengthSquared() > 1.0E-4) {
            double speed = Math.max(0.35, Math.min(2.4, (dist - 1.5) / 6.0));
            push = toward.normalize().multiply(speed).setY(0.4);
        }
        t.setVelocity(push);
        give(t, PotionEffectType.SLOWNESS, ticks(2, s), 0);
        sound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.8f, 0.5f);
        return true;
    }

    static boolean dimensionalSwap(Player p, double s) {
        LivingEntity t = rayTarget(p, 20);
        if (t == null) {
            return noTarget(p);
        }
        Location a = p.getLocation();
        Location b = t.getLocation();

        Location toCaster = b.clone();
        toCaster.setYaw(a.getYaw());
        toCaster.setPitch(a.getPitch());
        Location toTarget = a.clone();
        toTarget.setYaw(b.getYaw());
        toTarget.setPitch(b.getPitch());

        fx(chest(p), Particle.PORTAL, 30, 0.5, 0.3);
        fx(center(t).toLocation(t.getWorld()), Particle.PORTAL, 30, 0.5, 0.3);
        p.teleport(toCaster);
        t.teleport(toTarget);
        fx(chest(p), Particle.PORTAL, 30, 0.5, 0.3);
        fx(center(t).toLocation(t.getWorld()), Particle.PORTAL, 30, 0.5, 0.3);

        give(t, PotionEffectType.NAUSEA, ticks(4, s), 0);
        give(t, PotionEffectType.SLOWNESS, ticks(2, s), 0);
        sound(toCaster, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
        sound(toTarget, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
        return true;
    }

    // =====================================================================
    // LUMEN
    // =====================================================================

    static boolean flash(Player p, double s) {
        Location c = chest(p);
        for (LivingEntity t : nearby(p, c, 5)) {
            give(t, PotionEffectType.BLINDNESS, ticks(1.5, s), 0);
            give(t, PotionEffectType.GLOWING, ticks(6, s), 0);
        }
        fx(c, Particle.END_ROD, 60, 1.5, 0.15);
        ring(c.clone().add(0, -0.7, 0), 5, 40, Particle.END_ROD, null);
        sound(p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1f, 1.5f);
        return true;
    }

    static boolean aegis(Player p, double s) {
        // Real Absorption effect (4 HP per level) so it works on every 1.21 build.
        int amplifier = s >= 1.29 ? 2 : (s >= 0.95 ? 1 : 0);
        give(p, PotionEffectType.ABSORPTION, 200, amplifier);
        fx(chest(p), Particle.TOTEM_OF_UNDYING, 30, 0.4, 0.25);
        sound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1f, 1.5f);
        return true;
    }

    // =====================================================================
    // HELPERS
    // =====================================================================

    /** Seconds -> ticks, scaled by power. */
    static int ticks(double seconds, double power) {
        return Math.max(1, (int) Math.round(seconds * power * 20));
    }

    static boolean noTarget(Player p) {
        ShardCore.msg(p, "<gray>No target in sight.</gray>");
        return false;
    }

    /** Anything an ability may affect. */
    static boolean valid(Player caster, Entity e) {
        if (!(e instanceof LivingEntity) || e.equals(caster) || e.isDead() || !e.isValid()) {
            return false;
        }
        if (e instanceof ArmorStand) {
            return false;
        }
        if (e instanceof Player other) {
            GameMode gm = other.getGameMode();
            if (gm == GameMode.SPECTATOR || gm == GameMode.CREATIVE) {
                return false;
            }
        }
        if (e instanceof Tameable pet && caster.getUniqueId().equals(pet.getOwnerUniqueId())) {
            return false;
        }
        return true;
    }

    static Vector center(Entity e) {
        return e.getBoundingBox().getCenter();
    }

    static Location chest(Player p) {
        return p.getLocation().add(0, 1, 0);
    }

    static Location muzzle(Player p) {
        Location eye = p.getEyeLocation();
        return eye.add(eye.getDirection().multiply(0.6)).add(0, -0.2, 0);
    }

    /** First valid living entity under the crosshair (blocks stop the ray). */
    static LivingEntity rayTarget(Player p, double range) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTrace(eye, eye.getDirection(), range,
                FluidCollisionMode.NEVER, true, 0.5, e -> valid(p, e));
        if (r == null) {
            return null;
        }
        return r.getHitEntity() instanceof LivingEntity le ? le : null;
    }

    /** How far a straight line from the eyes goes before hitting a block. */
    static double freeRange(Player p, double range) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceBlocks(eye, eye.getDirection(), range,
                FluidCollisionMode.NEVER, true);
        return r == null ? range : Math.max(1, eye.toVector().distance(r.getHitPosition()));
    }

    static List<LivingEntity> nearby(Player caster, Location c, double r) {
        List<LivingEntity> out = new ArrayList<>();
        Vector cv = c.toVector();
        for (Entity e : c.getWorld().getNearbyEntities(c, r, r, r)) {
            if (valid(caster, e) && center(e).distanceSquared(cv) <= r * r) {
                out.add((LivingEntity) e);
            }
        }
        return out;
    }

    static LivingEntity nearest(Player caster, Location c, double r, Set<UUID> exclude) {
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        Vector cv = c.toVector();
        for (LivingEntity le : nearby(caster, c, r)) {
            if (exclude.contains(le.getUniqueId())) {
                continue;
            }
            double d = center(le).distanceSquared(cv);
            if (d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        return best;
    }

    /** Entities close to a straight line from the caster's eyes. */
    static List<LivingEntity> lineTargets(Player p, double range, double radius) {
        Location eye = p.getEyeLocation();
        Vector start = eye.toVector();
        Vector dir = eye.getDirection();
        Vector end = start.clone().add(dir.clone().multiply(range));
        Location mid = start.clone().add(end).multiply(0.5).toLocation(p.getWorld());
        double half = range / 2 + radius;

        List<LivingEntity> out = new ArrayList<>();
        for (Entity e : p.getWorld().getNearbyEntities(mid, half, half, half)) {
            if (!valid(p, e)) {
                continue;
            }
            Vector c = center(e);
            double along = Math.max(0, Math.min(range, c.clone().subtract(start).dot(dir)));
            Vector closest = start.clone().add(dir.clone().multiply(along));
            if (closest.distanceSquared(c) <= radius * radius) {
                out.add((LivingEntity) e);
            }
        }
        return out;
    }

    /** Ability damage (respects armor / resistance like normal damage). */
    static void hit(Player caster, LivingEntity target, double amount) {
        dealingAbilityDamage = true;
        try {
            target.damage(amount, caster);
        } finally {
            dealingAbilityDamage = false;
        }
    }

    /** Horizontal knockback away from {@code from}, plus a little lift. */
    static void knock(Location from, LivingEntity t, double strength, double lift) {
        Vector v = center(t).subtract(from.toVector());
        v.setY(0);
        if (v.lengthSquared() < 1.0E-4) {
            v = new Vector(1, 0, 0);
        }
        t.setVelocity(v.normalize().multiply(strength).setY(lift));
    }

    /** Apply an effect unless the target already has an equal or stronger one. */
    static void give(LivingEntity e, PotionEffectType type, int ticks, int amplifier) {
        PotionEffect cur = e.getPotionEffect(type);
        if (cur != null && (cur.getAmplifier() > amplifier
                || (cur.getAmplifier() == amplifier && cur.getDuration() >= ticks))) {
            return;
        }
        e.addPotionEffect(new PotionEffect(type, Math.max(1, ticks), amplifier));
    }

    /** Keep a lingering effect alive without resetting its damage timer every pulse. */
    static void maintain(LivingEntity e, PotionEffectType type, int ticks, int amplifier) {
        PotionEffect cur = e.getPotionEffect(type);
        if (cur == null || cur.getAmplifier() < amplifier
                || (cur.getAmplifier() == amplifier && cur.getDuration() <= 10)) {
            e.addPotionEffect(new PotionEffect(type, ticks, amplifier));
        }
    }

    /** Visual frost overlay only (stays below the freeze-damage threshold). */
    static void chill(LivingEntity t) {
        t.setFreezeTicks(Math.min(t.getMaxFreezeTicks() - 1, Math.max(t.getFreezeTicks(), 100)));
    }

    /** Two blocks of standing room, no liquids. */
    private static boolean hasRoom(Location l) {
        for (double dy : new double[] {0, 1, 1.8}) {
            Block b = l.clone().add(0, dy, 0).getBlock();
            if (!b.isPassable() || b.isLiquid()) {
                return false;
            }
        }
        return true;
    }

    // ----- effects -----

    static void sound(Location l, Sound sound, float volume, float pitch) {
        l.getWorld().playSound(l, sound, volume, pitch);
    }

    static void fx(Location l, Particle particle, int count, double spread, double speed) {
        l.getWorld().spawnParticle(particle, l, count, spread, spread, spread, speed);
    }

    static void fx(Location l, Particle particle, int count, double spread, double speed, Object data) {
        l.getWorld().spawnParticle(particle, l, count, spread, spread, spread, speed, data);
    }

    private static void dot(Location l, Particle particle, Object data) {
        if (data == null) {
            l.getWorld().spawnParticle(particle, l, 1, 0, 0, 0, 0);
        } else {
            l.getWorld().spawnParticle(particle, l, 1, 0, 0, 0, 0, data);
        }
    }

    static void line(Location from, Location to, Particle particle, Object data, double perBlock) {
        Vector d = to.toVector().subtract(from.toVector());
        double len = d.length();
        if (len < 0.1) {
            return;
        }
        d.multiply(1.0 / len);
        for (double i = 0; i <= len; i += 1.0 / perBlock) {
            dot(from.clone().add(d.clone().multiply(i)), particle, data);
        }
    }

    static void ring(Location c, double radius, int points, Particle particle, Object data) {
        World w = c.getWorld();
        if (w == null) {
            return;
        }
        for (int i = 0; i < points; i++) {
            double a = 2 * Math.PI * i / points;
            dot(c.clone().add(Math.cos(a) * radius, 0, Math.sin(a) * radius), particle, data);
        }
    }
}
