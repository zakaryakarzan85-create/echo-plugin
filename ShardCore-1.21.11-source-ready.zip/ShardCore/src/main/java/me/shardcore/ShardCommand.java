package me.shardcore;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * /shard                          - your shard, lives and abilities
 * /shard list                     - all shards
 * /shard lives <set|add> <player> <n>   (OP)
 * /shard set <player> <shard>           (OP)
 * /shard give <player> [amount]         (OP) gives Reroll Shards
 */
public final class ShardCommand implements TabExecutor {

    private final ShardCore plugin;

    public ShardCommand(ShardCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player p) {
                info(p);
            } else {
                ShardCore.msg(sender, "<gray>Usage: /shard <list|lives|set|give></gray>");
            }
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "info" -> {
                if (sender instanceof Player p) {
                    info(p);
                }
            }
            case "list" -> list(sender);
            case "lives" -> adminLives(sender, args);
            case "set" -> adminSet(sender, args);
            case "give" -> adminGive(sender, args);
            default -> ShardCore.msg(sender, "<gray>Usage: /shard [list|lives|set|give]</gray>");
        }
        return true;
    }

    // ------------------------------------------------------------ views

    private void info(Player p) {
        ShardManager sm = plugin.shards();
        ShardType type = sm.getShard(p);
        int lives = sm.getLives(p);

        ShardCore.raw(p, "<dark_gray>-----</dark_gray> " + type.colored() + " <gray>shard</gray> <dark_gray>-----</dark_gray>");
        ShardCore.raw(p, "<red>\u2665 Lives:</red> <white>" + lives + "/" + ShardManager.MAX_LIVES + "</white>"
                + " <gray>| Power:</gray> <white>x" + String.format(Locale.ROOT, "%.2f", sm.scale(p)) + "</white>");
        for (int slot = 1; slot <= 2; slot++) {
            String cmd = slot == 1 ? "/attack" : "/attack 2";
            ShardCore.raw(p, "<yellow>" + cmd + "</yellow> <dark_gray>-</dark_gray> <" + type.color() + ">"
                    + type.abilityName(slot) + "</" + type.color() + "> <gray>(" + sm.cooldownSeconds(slot) + "s)</gray>");
            ShardCore.raw(p, "  <gray>" + type.abilityDesc(slot) + "</gray>");
        }
        ShardCore.raw(p, "<dark_gray>Numbers shown at 3 lives. More lives = stronger abilities (1 life x0.80 ... 6 lives x1.30).</dark_gray>");
    }

    private void list(CommandSender sender) {
        ShardCore.raw(sender, "<dark_gray>-----</dark_gray> <light_purple>All shards</light_purple> <dark_gray>-----</dark_gray>");
        for (ShardType t : ShardType.values()) {
            ShardCore.raw(sender, t.colored() + " <dark_gray>-</dark_gray> <gray>" + t.abilityName(1)
                    + " / " + t.abilityName(2) + "</gray>");
        }
    }

    // ------------------------------------------------------------ admin

    private boolean requireOp(CommandSender sender) {
        if (!sender.isOp()) {
            ShardCore.msg(sender, "<red>Only operators can do that.</red>");
            return false;
        }
        return true;
    }

    private void adminLives(CommandSender sender, String[] args) {
        if (!requireOp(sender)) {
            return;
        }
        if (args.length < 4) {
            ShardCore.msg(sender, "<gray>Usage: /shard lives <set|add> <player> <number></gray>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) {
            ShardCore.msg(sender, "<red>Player not found.</red>");
            return;
        }
        int n;
        try {
            n = Integer.parseInt(args[3]);
        } catch (NumberFormatException ex) {
            ShardCore.msg(sender, "<red>'" + args[3].replace("<", "") + "' is not a number.</red>");
            return;
        }
        ShardManager sm = plugin.shards();
        int result;
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "set" -> result = sm.setLives(target, n);
            case "add" -> result = sm.addLives(target, n);
            default -> {
                ShardCore.msg(sender, "<gray>Usage: /shard lives <set|add> <player> <number></gray>");
                return;
            }
        }
        ShardCore.msg(sender, "<gray>" + target.getName() + " now has</gray> <white>" + result + "</white> <gray>lives (min "
                + ShardManager.MIN_LIVES + ", max " + ShardManager.MAX_LIVES + ").</gray>");
        ShardCore.msg(target, "<gray>Your shard lives are now</gray> <white>" + result + "/" + ShardManager.MAX_LIVES + "</white>");
    }

    private void adminSet(CommandSender sender, String[] args) {
        if (!requireOp(sender)) {
            return;
        }
        if (args.length < 3) {
            ShardCore.msg(sender, "<gray>Usage: /shard set <player> <shard></gray>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        ShardType type = ShardType.fromId(args[2]);
        if (target == null || type == null) {
            ShardCore.msg(sender, "<red>Unknown player or shard.</red> <gray>Use /shard list.</gray>");
            return;
        }
        plugin.shards().setShard(target, type);
        ShardCore.msg(sender, "<gray>" + target.getName() + " is now</gray> " + type.colored());
        ShardCore.msg(target, "<gray>Your shard is now</gray> " + type.colored());
    }

    private void adminGive(CommandSender sender, String[] args) {
        if (!requireOp(sender)) {
            return;
        }
        if (args.length < 2) {
            ShardCore.msg(sender, "<gray>Usage: /shard give <player> [amount]</gray>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            ShardCore.msg(sender, "<red>Player not found.</red>");
            return;
        }
        int amount = 1;
        if (args.length >= 3) {
            try {
                amount = Math.max(1, Math.min(64, Integer.parseInt(args[2])));
            } catch (NumberFormatException ignored) {
                // keep 1
            }
        }
        ItemStack stack = plugin.rerollItem().create(amount);
        target.getInventory().addItem(stack).values()
                .forEach(left -> target.getWorld().dropItemNaturally(target.getLocation(), left));
        ShardCore.msg(sender, "<gray>Gave " + amount + " Reroll Shard(s) to " + target.getName() + ".</gray>");
    }

    // ------------------------------------------------------------ tab complete

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.add("list");
            if (sender.isOp()) {
                out.addAll(List.of("lives", "set", "give"));
            }
        } else if (sender.isOp()) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (args.length == 2 && sub.equals("lives")) {
                out.addAll(List.of("set", "add"));
            } else if ((args.length == 2 && (sub.equals("set") || sub.equals("give")))
                    || (args.length == 3 && sub.equals("lives"))) {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    out.add(p.getName());
                }
            } else if (args.length == 3 && sub.equals("set")) {
                for (ShardType t : ShardType.values()) {
                    out.add(t.id());
                }
            }
        }
        String last = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
