package me.shardcore;

import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;

/** /attack = ability 1, /attack 2 = ability 2. */
public final class AttackCommand implements TabExecutor {

    private final ShardCore plugin;

    public AttackCommand(ShardCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Only players can use shard abilities.");
            return true;
        }

        int slot = 1;
        if (args.length > 0) {
            if (args[0].equals("2")) {
                slot = 2;
            } else if (!args[0].equals("1")) {
                ShardCore.msg(p, "<gray>Usage: <yellow>/attack</yellow> (ability 1) or <yellow>/attack 2</yellow> (ability 2)</gray>");
                return true;
            }
        }

        if (p.isDead() || p.getGameMode() == GameMode.SPECTATOR) {
            return true;
        }

        ShardManager sm = plugin.shards();
        ShardType type = sm.getShard(p);

        long remaining = sm.remainingMs(p, slot);
        if (remaining > 0) {
            ShardCore.msg(p, "<red>" + type.abilityName(slot) + " is on cooldown:</red> <gray>"
                    + String.format(Locale.ROOT, "%.1f", remaining / 1000.0) + "s</gray>");
            return true;
        }

        double power = sm.scale(p);
        boolean used = type.ability(slot).cast(p, power);
        if (used) {
            sm.startCooldown(p, slot);
            ShardCore.msg(p, "<" + type.color() + ">\u2726 " + type.abilityName(slot) + "</" + type.color() + "> "
                    + "<gray>(power x" + String.format(Locale.ROOT, "%.2f", power) + ")</gray>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return args.length == 1 ? List.of("1", "2") : List.of();
    }
}
