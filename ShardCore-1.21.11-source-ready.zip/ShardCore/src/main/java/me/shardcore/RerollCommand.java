package me.shardcore;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** /reroll [player] - operators only. Gives the player a different random shard (lives are kept). */
public final class RerollCommand implements TabExecutor {

    private final ShardCore plugin;

    public RerollCommand(ShardCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.isOp()) {
            ShardCore.msg(sender, "<red>Only operators can use /reroll.</red>");
            return true;
        }

        Player target;
        if (args.length == 0) {
            if (sender instanceof Player self) {
                target = self;
            } else {
                ShardCore.msg(sender, "<gray>Usage: /reroll <player></gray>");
                return true;
            }
        } else {
            target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                ShardCore.msg(sender, "<red>Player not found (they must be online).</red>");
                return true;
            }
        }

        ShardManager sm = plugin.shards();
        ShardType old = sm.getShard(target);
        ShardType now = sm.reroll(target);

        ShardCore.msg(target, "<light_purple>Your shard was rerolled!</light_purple> " + old.colored()
                + " <gray>\u2192</gray> " + now.colored());
        if (!sender.equals(target)) {
            ShardCore.msg(sender, "<gray>Rerolled " + target.getName() + ":</gray> " + old.colored()
                    + " <gray>\u2192</gray> " + now.colored());
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1 && sender.isOp()) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    out.add(p.getName());
                }
            }
        }
        return out;
    }
}
