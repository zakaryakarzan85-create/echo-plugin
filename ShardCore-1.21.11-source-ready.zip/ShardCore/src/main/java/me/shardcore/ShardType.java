package me.shardcore;

import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * The 10 shards. Every shard follows the same power budget:
 *  - Ability 1 (/attack):   20s cooldown, roughly 6-7 HP of value (damage, healing, or equivalent control).
 *  - Ability 2 (/attack 2): 45s cooldown, roughly 9-11 HP of value, harder to land or situational.
 * Numbers in the descriptions are at 3 lives (x1.00 power).
 */
public enum ShardType {

    EMBER("ember", "Ember", "red",
            "Fire Lance", "Shoot a lance of fire (20 blocks): 4 damage + 3s burn.", Abilities::fireLance,
            "Inferno Ring", "Flames burst around you (5 blocks): 6 damage + 4s burn + knockback.", Abilities::infernoRing),

    GALE("gale", "Gale", "white",
            "Gust Dash", "Dash forward, hitting everything in your path for 3 damage + knockback.", Abilities::gustDash,
            "Cyclone", "Whirlwind around you (5 blocks): 4 damage, launches enemies, Slowness I 3s.", Abilities::cyclone),

    TERRA("terra", "Terra", "gold",
            "Stone Skin", "Harden for 5s: Resistance II, but Slowness I.", Abilities::stoneSkin,
            "Rock Spike", "Spikes erupt in a 10 block line: 6 damage, launch, Slowness II 2s.", Abilities::rockSpike),

    VOLT("volt", "Volt", "yellow",
            "Chain Lightning", "Bolt hits a target (18 blocks) for 5, then jumps to up to 2 more nearby for 3 each.", Abilities::chainLightning,
            "Thunder Call", "Mark a spot (25 blocks). After 1.2s lightning hits a 3 block radius for 7 damage.", Abilities::thunderCall),

    FROST("frost", "Frost", "aqua",
            "Frost Bolt", "Icy bolt (20 blocks): 3 damage + Slowness II 4s.", Abilities::frostBolt,
            "Absolute Zero", "Freezing burst around you (5 blocks): 3 damage + Slowness III 3s.", Abilities::absoluteZero),

    VENOM("venom", "Venom", "dark_green",
            "Toxic Dart", "Poison dart (20 blocks): 2 damage + Poison II 3s.", Abilities::toxicDart,
            "Plague Cloud", "Leave a 5s toxic cloud (4 blocks): Poison I + Slowness I to enemies inside.", Abilities::plagueCloud),

    SHADE("shade", "Shade", "dark_gray",
            "Shadow Step", "Blink up to 7 blocks where you look.", Abilities::shadowStep,
            "Veil of Night", "Invisibility + Speed I for 4s, enemies within 6 blocks are blinded for 2s.", Abilities::veilOfNight),

    VERDANT("verdant", "Verdant", "green",
            "Regrowth", "Regeneration III for 4s (about 6 HP healed).", Abilities::regrowth,
            "Thorn Aura", "6s: Resistance I and attackers take 35% of melee damage back (max 4).", Abilities::thornAura),

    VOID("void", "Void", "dark_purple",
            "Singularity Pull", "Yank a target (18 blocks) toward you: 2 damage + Slowness I 2s.", Abilities::singularityPull,
            "Dimensional Swap", "Swap places with a target (20 blocks). They get Nausea 4s + Slowness I 2s.", Abilities::dimensionalSwap),

    LUMEN("lumen", "Lumen", "light_purple",
            "Flash", "Radiant flash (5 blocks): enemies get Blindness 1.5s + Glowing 6s.", Abilities::flash,
            "Aegis", "Absorption shield for 10s (I at 1-2 lives, II at 3-5, III at 6).", Abilities::aegis);

    @FunctionalInterface
    public interface Ability {
        /** @return true if the ability was used (cooldown starts), false if it fizzled (no cooldown). */
        boolean cast(Player caster, double power);
    }

    private final String id;
    private final String display;
    private final String color;
    private final String[] abilityNames = new String[3];
    private final String[] abilityDescs = new String[3];
    private final Ability[] abilities = new Ability[3];

    ShardType(String id, String display, String color,
              String name1, String desc1, Ability ability1,
              String name2, String desc2, Ability ability2) {
        this.id = id;
        this.display = display;
        this.color = color;
        abilityNames[1] = name1;
        abilityDescs[1] = desc1;
        abilities[1] = ability1;
        abilityNames[2] = name2;
        abilityDescs[2] = desc2;
        abilities[2] = ability2;
    }

    public String id() {
        return id;
    }

    public String display() {
        return display;
    }

    /** MiniMessage color name, e.g. "red". */
    public String color() {
        return color;
    }

    /** MiniMessage-colored name, e.g. {@code <red>Ember</red>}. */
    public String colored() {
        return "<" + color + ">" + display + "</" + color + ">";
    }

    public String abilityName(int slot) {
        return abilityNames[slot];
    }

    public String abilityDesc(int slot) {
        return abilityDescs[slot];
    }

    public Ability ability(int slot) {
        return abilities[slot];
    }

    public static ShardType fromId(String id) {
        if (id == null) {
            return null;
        }
        for (ShardType t : values()) {
            if (t.id.equalsIgnoreCase(id)) {
                return t;
            }
        }
        return null;
    }

    /** Random shard, never {@code except} (pass null to allow any). */
    public static ShardType random(ShardType except) {
        List<ShardType> pool = new ArrayList<>();
        for (ShardType t : values()) {
            if (t != except) {
                pool.add(t);
            }
        }
        return pool.get(ThreadLocalRandom.current().nextInt(pool.size()));
    }
}
