package me.shardcore;

import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.CraftingInventory;
import org.bukkit.inventory.ItemStack;

public final class ShardListener implements Listener {

    private final ShardCore plugin;

    public ShardListener(ShardCore plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------ join / quit

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        ShardManager sm = plugin.shards();

        boolean first = !sm.has(p.getUniqueId());
        sm.ensure(p); // new players get a random shard with 3 lives
        p.discoverRecipe(plugin.rerollItem().recipeKey());

        ShardType type = sm.getShard(p);
        if (first) {
            ShardCore.msg(p, "You awakened the " + type.colored() + " shard! Use <yellow>/attack</yellow> and "
                    + "<yellow>/attack 2</yellow>. Type <yellow>/shard</yellow> for details.");
        } else {
            ShardCore.msg(p, "Your shard: " + type.colored() + " <gray>(" + sm.getLives(p) + " lives)</gray>");
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Abilities.THORNS.remove(e.getPlayer().getUniqueId());
        plugin.shards().saveIfDirty();
    }

    // ------------------------------------------------------------ lives

    /**
     * The shard is stored by UUID, not as an item, so it can never drop and is identical after respawn.
     * Only the lives change here.
     */
    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        ShardManager sm = plugin.shards();
        Abilities.THORNS.remove(victim.getUniqueId());

        if (plugin.getConfig().getBoolean("lives.lose-on-death", true)) {
            int before = sm.getLives(victim);
            int after = sm.addLives(victim, -1);
            if (after < before) {
                ShardCore.msg(victim, "<red>You lost a shard life</red> <gray>(" + before + " \u2192 " + after
                        + "). Your " + sm.getShard(victim).colored() + " shard is kept.</gray>");
            } else {
                ShardCore.msg(victim, "<gray>You are at the minimum of " + ShardManager.MIN_LIVES
                        + " life. Your " + sm.getShard(victim).colored() + " shard is kept.</gray>");
            }
        }

        Player killer = victim.getKiller();
        if (killer != null && !killer.equals(victim)
                && plugin.getConfig().getBoolean("lives.gain-on-kill", true)) {
            int before = sm.getLives(killer);
            int after = sm.addLives(killer, 1);
            if (after > before) {
                ShardCore.msg(killer, "<green>+1 shard life</green> <gray>(" + before + " \u2192 " + after + ")</gray>");
            } else {
                ShardCore.msg(killer, "<gray>You are already at the maximum of " + ShardManager.MAX_LIVES + " lives.</gray>");
            }
        }
    }

    // ------------------------------------------------------------ Thorn Aura (Verdant passive window)

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onThorns(EntityDamageByEntityEvent e) {
        if (Abilities.dealingAbilityDamage || !(e.getEntity() instanceof Player victim)) {
            return;
        }
        Abilities.Aura aura = Abilities.THORNS.get(victim.getUniqueId());
        if (aura == null) {
            return;
        }
        if (System.currentTimeMillis() > aura.expiresAt()) {
            Abilities.THORNS.remove(victim.getUniqueId());
            return;
        }
        // Melee only.
        Entity damager = e.getDamager();
        if (e.getCause() != DamageCause.ENTITY_ATTACK || !(damager instanceof LivingEntity attacker)
                || attacker.equals(victim) || attacker.isDead()) {
            return;
        }
        double reflected = Math.min(e.getFinalDamage() * 0.35, 4 * aura.power());
        if (reflected <= 0) {
            return;
        }
        attacker.damage(reflected); // no source -> cannot trigger this handler again
        attacker.getWorld().spawnParticle(Particle.CRIT, attacker.getLocation().add(0, 1, 0), 8, 0.3, 0.4, 0.3, 0.1);
    }

    // ------------------------------------------------------------ Reroll Shard item

    @EventHandler
    public void onUseRerollShard(PlayerInteractEvent e) {
        if (e.getHand() == null
                || (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK)) {
            return;
        }
        Player p = e.getPlayer();
        ItemStack item = p.getInventory().getItem(e.getHand());
        if (!plugin.rerollItem().is(item)) {
            return;
        }
        e.setCancelled(true);
        item.setAmount(item.getAmount() - 1);

        ShardManager sm = plugin.shards();
        ShardType old = sm.getShard(p);
        ShardType now = sm.reroll(p);
        ShardCore.msg(p, "<light_purple>The Reroll Shard shatters!</light_purple> " + old.colored()
                + " <gray>\u2192</gray> " + now.colored());
        p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, p.getLocation().add(0, 1, 0), 40, 0.5, 0.8, 0.5, 0.3);
        p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1f);
    }

    /** The Reroll Shard is an echo shard underneath; stop it being used in vanilla recipes. */
    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent e) {
        CraftingInventory inv = e.getInventory();
        for (ItemStack it : inv.getMatrix()) {
            if (it != null && plugin.rerollItem().is(it)) {
                inv.setResult(null);
                return;
            }
        }
    }
}
