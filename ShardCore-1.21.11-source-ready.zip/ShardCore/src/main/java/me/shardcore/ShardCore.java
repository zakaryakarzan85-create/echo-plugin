package me.shardcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class ShardCore extends JavaPlugin {

    public static final String PREFIX = "<dark_gray>[<light_purple>Shards</light_purple>]</dark_gray> ";
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private static ShardCore instance;
    private ShardManager shards;
    private RerollItem rerollItem;

    public static ShardCore instance() {
        return instance;
    }

    public ShardManager shards() {
        return shards;
    }

    public RerollItem rerollItem() {
        return rerollItem;
    }

    /** Parse a MiniMessage string. */
    public static Component mm(String text) {
        return MM.deserialize(text);
    }

    /** Send a prefixed MiniMessage line. */
    public static void msg(CommandSender to, String text) {
        to.sendMessage(mm(PREFIX + text));
    }

    /** Send a MiniMessage line without the prefix. */
    public static void raw(CommandSender to, String text) {
        to.sendMessage(mm(text));
    }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        shards = new ShardManager(this);
        shards.load();

        rerollItem = new RerollItem(this);
        rerollItem.registerRecipe();

        getServer().getPluginManager().registerEvents(new ShardListener(this), this);

        bind("attack", new AttackCommand(this));
        bind("reroll", new RerollCommand(this));
        bind("shard", new ShardCommand(this));

        // Autosave every minute (and on disable / quit).
        getServer().getScheduler().runTaskTimer(this, shards::saveIfDirty, 20L * 60, 20L * 60);

        if (getConfig().getBoolean("action-bar", true)) {
            getServer().getScheduler().runTaskTimer(this, this::tickHud, 20L, 20L);
        }

        // Covers /reload: make sure everyone online has a shard.
        for (Player p : getServer().getOnlinePlayers()) {
            shards.ensure(p);
            p.discoverRecipe(rerollItem.recipeKey());
        }

        getLogger().info("ShardCore enabled with " + ShardType.values().length + " shards.");
    }

    @Override
    public void onDisable() {
        if (shards != null) {
            shards.save();
        }
        if (rerollItem != null) {
            rerollItem.unregisterRecipe();
        }
    }

    private void bind(String name, TabExecutor executor) {
        PluginCommand cmd = getCommand(name);
        if (cmd == null) {
            getLogger().severe("Command '" + name + "' is missing from plugin.yml!");
            return;
        }
        cmd.setExecutor(executor);
        cmd.setTabCompleter(executor);
    }

    private void tickHud() {
        for (Player p : getServer().getOnlinePlayers()) {
            p.sendActionBar(mm(shards.hud(p)));
        }
    }
}
