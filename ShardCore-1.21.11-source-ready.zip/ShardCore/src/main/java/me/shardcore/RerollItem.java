package me.shardcore;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

/**
 * The craftable "Reroll Shard". Right-click it to consume it and reroll your own shard.
 *
 * Recipe (shaped):
 *   A D A      A = Amethyst Shard
 *   D N D      D = Diamond
 *   A D A      N = Nether Star
 */
public final class RerollItem {

    private final NamespacedKey itemKey;
    private final NamespacedKey recipeKey;

    public RerollItem(ShardCore plugin) {
        this.itemKey = new NamespacedKey(plugin, "reroll_shard");
        this.recipeKey = new NamespacedKey(plugin, "reroll_shard_recipe");
    }

    public NamespacedKey recipeKey() {
        return recipeKey;
    }

    public ItemStack create(int amount) {
        ItemStack item = new ItemStack(Material.ECHO_SHARD, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        meta.displayName(ShardCore.mm("<!italic><light_purple><bold>Reroll Shard</bold></light_purple>"));
        meta.lore(List.of(
                ShardCore.mm("<!italic><gray>Right-click to consume and</gray>"),
                ShardCore.mm("<!italic><gray>reroll your shard.</gray>"),
                ShardCore.mm("<!italic><dark_gray>Your lives are kept.</dark_gray>")));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    public boolean is(ItemStack item) {
        if (item == null || item.getType() != Material.ECHO_SHARD || !item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(itemKey, PersistentDataType.BYTE);
    }

    public void registerRecipe() {
        Bukkit.removeRecipe(recipeKey); // safe on /reload
        ShapedRecipe recipe = new ShapedRecipe(recipeKey, create(1));
        recipe.shape("ADA", "DND", "ADA");
        recipe.setIngredient('A', Material.AMETHYST_SHARD);
        recipe.setIngredient('D', Material.DIAMOND);
        recipe.setIngredient('N', Material.NETHER_STAR);
        Bukkit.addRecipe(recipe);
    }

    public void unregisterRecipe() {
        Bukkit.removeRecipe(recipeKey);
    }
}
