# ShardCore (Paper 1.21.x)

Ten balanced shards, two abilities each, scaled by a 1-6 life system.

## Build (Paper 1.21.11)
Requires JDK 21 and Maven. Double-click `build.bat` (Windows) or run `./build.sh`, or:

```
mvn clean package
```
Copy `target/ShardCore-1.0.0.jar` into your server's `plugins/` folder and restart.

No Java on your PC? Push this folder to a GitHub repo: the included workflow
(`.github/workflows/build.yml`) builds the jar for you. Open the Actions tab, run it, and download `ShardCore-jar`.

## Commands
| Command | Who | What |
|---|---|---|
| `/attack` | everyone | Ability 1 |
| `/attack 2` | everyone | Ability 2 |
| `/reroll [player]` | **OP only** | Gives the player a different random shard (lives kept) |
| `/shard` | everyone | Your shard, lives, power and abilities |
| `/shard list` | everyone | All shards |
| `/shard lives <set\|add> <player> <n>` | OP | Edit lives (clamped 1-6) |
| `/shard set <player> <shard>` | OP | Force a shard (testing) |
| `/shard give <player> [amount]` | OP | Give Reroll Shards (testing) |

## Shard rules
- Every player gets a random shard on first join and keeps it forever (saved by UUID in `players.yml`).
  It is not an item, so it can never drop on death and is identical after respawn. Only `/reroll` or a Reroll Shard changes it.
- **Reroll Shard** (craftable, right-click to use, consumed):
  ```
  A D A     A = Amethyst Shard
  D N D     D = Diamond
  A D A     N = Nether Star
  ```
- **Lives:** start at 3, min 1, max 6. Dying costs 1 life, killing a player gives 1 life (both toggleable in `config.yml`).
- **Power scaling** (every ability, every shard, identical): 1 life x0.80, 2 x0.90, 3 x1.00, 4 x1.10, 5 x1.20, 6 x1.30.
  It scales damage, durations, dash/blink distance and healing. Lumen's Aegis is Absorption I / II / III at 1-2 / 3-5 / 6 lives.

## Balance rules
- Ability 1 cooldown is 20s and Ability 2 cooldown is 45s for **every** shard.
- Ability 1 is worth about 6-7 HP (damage, healing, or equivalent control). Ability 2 is worth about 9-11 HP but is harder to land, delayed, or situational.
- No passives, no block damage, no instant kills. Single-target abilities need a target (no cooldown spent if you miss).

| Shard | /attack (20s) | /attack 2 (45s) |
|---|---|---|
| Ember | Fire Lance: 4 dmg + 3s burn | Inferno Ring: r5, 6 dmg + 4s burn |
| Gale | Gust Dash: dash, 3 dmg to all hit | Cyclone: r5, 4 dmg + launch + Slow I |
| Terra | Stone Skin: Resistance II 5s, Slow I | Rock Spike: 10-block line, 6 dmg + launch + Slow II |
| Volt | Chain Lightning: 5 / 3 / 3 | Thunder Call: delayed r3 strike, 7 dmg |
| Frost | Frost Bolt: 3 dmg + Slow II 4s | Absolute Zero: r5, 3 dmg + Slow III 3s |
| Venom | Toxic Dart: 2 dmg + Poison II 3s | Plague Cloud: 5s zone, Poison I + Slow I |
| Shade | Shadow Step: blink 7 blocks | Veil of Night: Invis + Speed I 4s, enemies blind 2s |
| Verdant | Regrowth: Regen III 4s (~6 HP) | Thorn Aura: 6s, Resistance I + reflect 35% melee |
| Void | Singularity Pull: pull + 2 dmg + Slow I | Dimensional Swap: swap places, Nausea 4s |
| Lumen | Flash: r5, Blind 1.5s + Glowing 6s | Aegis: Absorption shield 10s |

All numbers are at 3 lives. Cooldowns and the scaling step live in `config.yml`.

## Build the JAR without installing Java or Maven (phone-friendly)

1. Create a repository on GitHub and upload the **contents of this `ShardCore` folder** (so `pom.xml` and `.github/` are at the repository root).
2. Open the repository's **Actions** tab and enable Actions if GitHub asks.
3. Select **Build ShardCore jar** → **Run workflow** (or push a commit to trigger it automatically).
4. Open the completed workflow run, scroll to **Artifacts**, and download **ShardCore-jar**.
5. Extract the downloaded artifact ZIP; the `.jar` inside goes into your Paper server's `plugins/` folder.
6. Restart the server and check the console for `ShardCore` loading successfully.

This project targets **Paper 1.21.11** and requires Java 21. It is not a Bukkit/Spigot-only guarantee; use a Paper server.
