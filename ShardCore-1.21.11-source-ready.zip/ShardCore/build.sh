#!/bin/sh
# Requires JDK 21 and Maven
mvn clean package && echo "Your jar is in target/ShardCore-1.0.0.jar"
